from __future__ import annotations

from typing import Any

from fastapi import FastAPI

from agents import DEFAULT_AGENT, get_all_agent_info
from api.study_routes import router as study_router


app = FastAPI(
    title="AI Study Companion",
    description="Local MVP for adaptive study planning, teaching, quizzes, and progress.",
)


@app.get("/health")
async def health_check() -> dict[str, Any]:
    return {"status": "ok"}


@app.get("/info")
async def info() -> dict[str, Any]:
    return {
        "agents": [agent.model_dump() for agent in get_all_agent_info()],
        "models": ["local-deterministic"],
        "default_agent": DEFAULT_AGENT,
        "default_model": "local-deterministic",
    }


app.include_router(study_router)
