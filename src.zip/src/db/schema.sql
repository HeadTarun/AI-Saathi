create table if not exists exams (
    id text primary key,
    name text unique not null,
    description text,
    syllabus_version text not null default '2026',
    is_active boolean not null default true,
    created_at timestamptz not null default now()
);

create table if not exists users (
    id text primary key,
    name text not null,
    email text unique not null,
    level text not null default 'beginner' check (level in ('beginner', 'intermediate', 'advanced')),
    target_exam_id text references exams(id),
    timezone text not null default 'Asia/Kolkata',
    created_at timestamptz not null default now()
);

create table if not exists syllabus_topics (
    id text primary key,
    exam_id text not null references exams(id),
    subject text not null,
    topic_name text not null,
    subtopics jsonb not null default '[]',
    difficulty smallint not null check (difficulty between 1 and 5),
    priority text not null check (priority in ('HIGH', 'MED', 'LOW')),
    estimated_hours numeric(4,1) not null default 0,
    prerequisite_ids jsonb not null default '[]',
    template_ids jsonb not null default '[]',
    created_at timestamptz not null default now()
);

create index if not exists idx_syllabus_exam_subject on syllabus_topics(exam_id, subject);

create table if not exists study_plans (
    id text primary key,
    user_id text not null references users(id),
    exam_id text not null references exams(id),
    level text not null default 'beginner',
    start_date date not null,
    end_date date not null,
    duration_days smallint not null,
    status text not null default 'active' check (status in ('active', 'completed', 'abandoned')),
    planner_version smallint not null default 1,
    meta jsonb not null default '{}',
    created_at timestamptz not null default now()
);

create index if not exists idx_study_plans_user_status on study_plans(user_id, status);

create table if not exists study_plan_days (
    id text primary key,
    plan_id text not null references study_plans(id) on delete cascade,
    day_number smallint not null check (day_number > 0),
    scheduled_date date not null,
    topic_id text not null references syllabus_topics(id),
    revision_topic_ids jsonb not null default '[]',
    allocated_minutes smallint not null default 90,
    status text not null default 'pending' check (status in ('pending', 'taught', 'skipped')),
    taught_at timestamptz
);

create index if not exists idx_plan_days_plan_date on study_plan_days(plan_id, scheduled_date);
create index if not exists idx_plan_days_topic on study_plan_days(topic_id);

create table if not exists quiz_templates (
    id text primary key,
    topic_id text not null references syllabus_topics(id),
    template_type text not null default 'mcq',
    difficulty smallint check (difficulty between 1 and 5),
    template_body jsonb not null default '{}',
    answer_key jsonb not null default '{}',
    usage_count integer not null default 0,
    is_active boolean not null default true,
    created_at timestamptz not null default now()
);

create table if not exists quiz_attempts (
    id text primary key,
    user_id text not null references users(id),
    topic_id text not null references syllabus_topics(id),
    plan_day_id text references study_plan_days(id),
    template_id text references quiz_templates(id),
    questions jsonb not null,
    user_answers jsonb not null default '[]',
    score smallint,
    total_questions smallint not null,
    difficulty smallint,
    accuracy numeric(5,2),
    time_taken_secs integer,
    attempted_at timestamptz not null default now(),
    submitted_at timestamptz
);

create index if not exists idx_quiz_user_topic_time on quiz_attempts(user_id, topic_id, attempted_at desc);

create table if not exists user_performance (
    id text primary key,
    user_id text not null references users(id),
    topic_id text not null references syllabus_topics(id),
    attempts integer not null default 0,
    correct integer not null default 0,
    accuracy numeric(5,2) not null default 0,
    avg_time_secs numeric(6,2) not null default 0,
    last_attempted timestamptz not null default now(),
    weakness_score numeric(5,2) not null default 50,
    unique (user_id, topic_id)
);

create index if not exists idx_perf_user_weakness on user_performance(user_id, weakness_score desc);

create table if not exists teaching_logs (
    id text primary key,
    plan_day_id text not null references study_plan_days(id),
    user_id text not null references users(id),
    topic_id text not null references syllabus_topics(id),
    content_summary text,
    revision_covered jsonb not null default '[]',
    llm_trace jsonb not null default '{}',
    duration_mins smallint,
    taught_at timestamptz not null default now()
);

create index if not exists idx_teaching_user_topic on teaching_logs(user_id, topic_id);

create extension if not exists vector;

create table if not exists rag_documents (
    id text primary key,
    filename text not null,
    storage_path text,
    created_at timestamptz not null default now()
);

create table if not exists rag_chunks (
    id text primary key,
    document_id text not null references rag_documents(id) on delete cascade,
    chunk_index integer not null,
    content text not null,
    metadata jsonb not null default '{}',
    embedding vector(384),
    created_at timestamptz not null default now()
);

create index if not exists idx_rag_chunks_document on rag_chunks(document_id, chunk_index);
create index if not exists idx_rag_chunks_embedding
    on rag_chunks using ivfflat (embedding vector_cosine_ops)
    with (lists = 100);

create or replace function match_rag_chunks(
    query_embedding vector(384),
    match_count integer default 5
)
returns table (
    id text,
    document_id text,
    content text,
    metadata jsonb,
    similarity double precision
)
language sql stable
as $$
    select
        rag_chunks.id,
        rag_chunks.document_id,
        rag_chunks.content,
        rag_chunks.metadata,
        1 - (rag_chunks.embedding <=> query_embedding) as similarity
    from rag_chunks
    where rag_chunks.embedding is not null
    order by rag_chunks.embedding <=> query_embedding
    limit match_count;
$$;

alter table rag_documents disable row level security;
alter table rag_chunks disable row level security;
