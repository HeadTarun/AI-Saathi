from __future__ import annotations

import random
import uuid
from copy import deepcopy
from datetime import date, datetime, timedelta
from typing import Any

from db import get_supabase


EXAMS = {
    "SSC CGL": "exam-ssc-cgl",
    "SBI PO": "exam-sbi-po",
    "IBPS PO": "exam-ibps-po",
}

EXAM_NAMES = {value: key for key, value in EXAMS.items()}

TOPICS_BY_EXAM = {
    "exam-ssc-cgl": [
        {"id": "t1", "name": "Percentage", "subject": "Quantitative Aptitude", "priority": "HIGH", "difficulty": 2, "hours": 3.0},
        {"id": "t2", "name": "Profit & Loss", "subject": "Quantitative Aptitude", "priority": "HIGH", "difficulty": 3, "hours": 3.5},
        {"id": "t3", "name": "Time & Work", "subject": "Quantitative Aptitude", "priority": "HIGH", "difficulty": 3, "hours": 3.0},
        {"id": "t4", "name": "Ratio & Proportion", "subject": "Quantitative Aptitude", "priority": "MED", "difficulty": 2, "hours": 2.5},
        {"id": "t5", "name": "Puzzles", "subject": "Logical Reasoning", "priority": "HIGH", "difficulty": 4, "hours": 4.0},
        {"id": "t6", "name": "Seating Arrangement", "subject": "Logical Reasoning", "priority": "HIGH", "difficulty": 4, "hours": 3.5},
        {"id": "t7", "name": "Coding-Decoding", "subject": "Logical Reasoning", "priority": "MED", "difficulty": 3, "hours": 2.5},
        {"id": "t8", "name": "Direction Sense", "subject": "Logical Reasoning", "priority": "MED", "difficulty": 2, "hours": 2.0},
    ],
    "exam-sbi-po": [
        {"id": "sbi-t1", "name": "Data Interpretation", "subject": "Quantitative Aptitude", "priority": "HIGH", "difficulty": 4, "hours": 5.0},
        {"id": "sbi-t2", "name": "Number Series", "subject": "Quantitative Aptitude", "priority": "HIGH", "difficulty": 3, "hours": 3.0},
        {"id": "sbi-t3", "name": "Simplification", "subject": "Quantitative Aptitude", "priority": "HIGH", "difficulty": 2, "hours": 2.5},
        {"id": "sbi-t5", "name": "Puzzles", "subject": "Logical Reasoning", "priority": "HIGH", "difficulty": 5, "hours": 5.0},
        {"id": "sbi-t6", "name": "Syllogisms", "subject": "Logical Reasoning", "priority": "MED", "difficulty": 3, "hours": 2.5},
        {"id": "sbi-t7", "name": "Input-Output", "subject": "Logical Reasoning", "priority": "MED", "difficulty": 4, "hours": 3.0},
    ],
    "exam-ibps-po": [
        {"id": "ibps-t1", "name": "Percentage", "subject": "Quantitative Aptitude", "priority": "HIGH", "difficulty": 2, "hours": 3.0},
        {"id": "ibps-t2", "name": "Simplification", "subject": "Quantitative Aptitude", "priority": "HIGH", "difficulty": 2, "hours": 2.5},
        {"id": "ibps-t3", "name": "Time & Work", "subject": "Quantitative Aptitude", "priority": "HIGH", "difficulty": 3, "hours": 3.0},
        {"id": "ibps-t4", "name": "Data Interpretation", "subject": "Quantitative Aptitude", "priority": "HIGH", "difficulty": 4, "hours": 4.5},
        {"id": "ibps-t5", "name": "Puzzles", "subject": "Logical Reasoning", "priority": "HIGH", "difficulty": 4, "hours": 4.0},
        {"id": "ibps-t6", "name": "Syllogisms", "subject": "Logical Reasoning", "priority": "MED", "difficulty": 3, "hours": 2.5},
    ],
}

LESSON_POINTS = {
    "Percentage": ["A percentage means a value out of 100.", "Use part / whole * 100 to compare quantities.", "For increase or decrease, always compare change with the original value."],
    "Profit & Loss": ["Profit is selling price minus cost price.", "Loss is cost price minus selling price.", "Profit percent and loss percent are always calculated on cost price."],
    "Time & Work": ["Work problems depend on rates.", "If a person completes work in n days, one day of work is 1/n.", "Add rates when people work together."],
    "Ratio & Proportion": ["A ratio compares two quantities.", "Equivalent ratios are made by multiplying or dividing both sides equally.", "In proportion, cross products are equal."],
    "Puzzles": ["Read every condition carefully.", "Create a compact table before placing values.", "Use fixed clues first, then relative clues."],
    "Seating Arrangement": ["Mark direction before placing people.", "Use a circle or row diagram based on the question.", "Treat left and right from the subject's perspective."],
    "Coding-Decoding": ["Look for alphabet shifts, reversals, and positional values.", "Apply the same rule to every letter.", "Test the rule on the full word before choosing an answer."],
    "Direction Sense": ["Draw every movement step by step.", "Keep north fixed unless the question rotates the person.", "Use distance geometry only after final position is clear."],
    "Data Interpretation": ["Read units and scale before calculating.", "Estimate first, then compute.", "Percent change and averages are frequent shortcuts."],
    "Number Series": ["Check differences, ratios, squares, and alternating patterns.", "Do not force one rule too early.", "Validate the pattern across all terms."],
    "Simplification": ["Follow BODMAS carefully.", "Convert percentages and fractions into familiar values.", "Approximation can save time in exams."],
    "Syllogisms": ["Use Venn diagrams for categorical statements.", "Check conclusions independently.", "Possibility conclusions need separate care."],
    "Input-Output": ["Compare each step with the previous one.", "Find whether sorting happens by number, word, or position.", "Predict only the next valid transformation."],
}

QUIZ_BANK = {
    "Percentage": [
        ("What is 25% of 240?", ["40", "50", "60", "80"], 2, "25% is one-fourth; 240 / 4 = 60."),
        ("A number increases from 80 to 100. What is the percentage increase?", ["20%", "25%", "30%", "40%"], 1, "Increase is 20 on original 80, so 20/80 * 100 = 25%."),
        ("If 15% of a number is 45, what is the number?", ["250", "275", "300", "350"], 2, "Number = 45 * 100 / 15 = 300."),
        ("What is 10% less than 650?", ["565", "575", "585", "595"], 2, "10% of 650 is 65; 650 - 65 = 585."),
        ("40 is what percent of 200?", ["15%", "20%", "25%", "30%"], 1, "40/200 * 100 = 20%."),
    ],
    "Profit & Loss": [
        ("Cost price is 500 and selling price is 650. Profit percent?", ["20%", "25%", "30%", "35%"], 2, "Profit is 150; 150/500 * 100 = 30%."),
        ("A 20% loss on CP 800 equals how much loss?", ["120", "140", "160", "180"], 2, "20% of 800 is 160."),
        ("If CP is 400 and profit is 25%, selling price is?", ["450", "475", "500", "525"], 2, "SP = 400 + 25% of 400 = 500."),
        ("Loss percent is calculated on which value?", ["Selling price", "Marked price", "Cost price", "Discount"], 2, "Profit and loss percentages are calculated on cost price."),
        ("SP 900, CP 750. Profit is?", ["100", "125", "150", "175"], 2, "900 - 750 = 150."),
    ],
    "default": [
        ("Which strategy is best before solving a topic question?", ["Guess fast", "Read conditions carefully", "Skip all formulas", "Ignore units"], 1, "Careful reading prevents avoidable mistakes."),
        ("What should you revise after a weak quiz score?", ["Only easy topics", "The same weak concept", "Nothing", "Unrelated topics"], 1, "Weak concepts need targeted revision."),
        ("Why are timed quizzes useful?", ["They hide mistakes", "They build exam speed", "They remove practice", "They replace concepts"], 1, "Timed practice improves speed and accuracy together."),
        ("What is a good first step for reasoning questions?", ["Draw or tabulate data", "Memorize answers", "Avoid clues", "Start from the last option"], 0, "A diagram or table keeps clues organized."),
        ("What does accuracy measure?", ["Correct answers out of attempts", "Total study hours", "Exam date", "Topic priority"], 0, "Accuracy is correct answers divided by attempts."),
    ],
}


def _table(name: str):
    return get_supabase().table(name)


def _data(response: Any) -> Any:
    return getattr(response, "data", None) or []


def _one(response: Any) -> dict[str, Any] | None:
    rows = _data(response)
    return rows[0] if rows else None


def _new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:12]}"


def _exam_id(value: str) -> str:
    return EXAMS.get(value, value if value in EXAM_NAMES else "exam-ssc-cgl")


def _topic_lookup() -> dict[str, dict[str, Any]]:
    topics = {}
    for exam_topics in TOPICS_BY_EXAM.values():
        for topic in exam_topics:
            topics.setdefault(topic["id"], topic)
            topics.setdefault(topic["name"], topic)
    return topics


def _seed_static_data() -> None:
    existing = _one(_table("exams").select("id").limit(1).execute())
    if existing:
        return

    exams = [
        {"id": exam_id, "name": name, "description": f"{name} preparation", "syllabus_version": "2026", "is_active": True}
        for name, exam_id in EXAMS.items()
    ]
    _table("exams").upsert(exams, on_conflict="id").execute()

    topics = []
    for exam_id, rows in TOPICS_BY_EXAM.items():
        for row in rows:
            topics.append(
                {
                    "id": row["id"],
                    "exam_id": exam_id,
                    "subject": row["subject"],
                    "topic_name": row["name"],
                    "subtopics": [],
                    "difficulty": row["difficulty"],
                    "priority": row["priority"],
                    "estimated_hours": row["hours"],
                    "prerequisite_ids": [],
                }
            )
    _table("syllabus_topics").upsert(topics, on_conflict="id").execute()


def _ensure_user(user_id: str, name: str = "Learner", level: str = "beginner", exam_id: str = "exam-ssc-cgl") -> dict[str, Any]:
    row = {
        "id": user_id,
        "name": name or "Learner",
        "email": f"{user_id}@local.study",
        "level": level or "beginner",
        "target_exam_id": exam_id,
        "timezone": "Asia/Kolkata",
    }
    return _one(_table("users").upsert(row, on_conflict="id").execute()) or row


def list_exams() -> dict[str, str]:
    _seed_static_data()
    rows = _data(_table("exams").select("id,name").eq("is_active", True).order("name").execute())
    return {row["name"]: row["id"] for row in rows} or deepcopy(EXAMS)


def list_topics(exam_id_or_name: str) -> list[dict[str, Any]]:
    _seed_static_data()
    exam_id = _exam_id(exam_id_or_name)
    rows = _data(
        _table("syllabus_topics")
        .select("*")
        .eq("exam_id", exam_id)
        .order("priority")
        .order("difficulty")
        .execute()
    )
    return [
        {
            "id": row["id"],
            "name": row["topic_name"],
            "topic_id": row["id"],
            "topic_name": row["topic_name"],
            "subject": row["subject"],
            "priority": row["priority"],
            "difficulty": row["difficulty"],
            "hours": float(row.get("estimated_hours") or 0),
            "estimated_hours": float(row.get("estimated_hours") or 0),
            "prerequisite_ids": row.get("prerequisite_ids") or [],
            "subtopics": row.get("subtopics") or [],
        }
        for row in rows
    ]


def _topic_map(topic_ids: list[str]) -> dict[str, dict[str, Any]]:
    if not topic_ids:
        return {}
    rows = _data(_table("syllabus_topics").select("*").in_("id", topic_ids).execute())
    return {row["id"]: row for row in rows}


def _plan_payload(plan: dict[str, Any]) -> dict[str, Any]:
    days = _data(
        _table("study_plan_days")
        .select("*")
        .eq("plan_id", plan["id"])
        .order("day_number")
        .execute()
    )
    topics = _topic_map([day["topic_id"] for day in days if day.get("topic_id")])
    exam_name = EXAM_NAMES.get(plan["exam_id"], plan["exam_id"])
    payload_days = []
    for day in days:
        topic = topics.get(day.get("topic_id"), {})
        payload_days.append(
            {
                "id": day["id"],
                "plan_day_id": day["id"],
                "day_number": day["day_number"],
                "scheduled_date": day["scheduled_date"],
                "topic_id": day["topic_id"],
                "topic": topic.get("topic_name", "Revision Day"),
                "topic_name": topic.get("topic_name", "Revision Day"),
                "subject": topic.get("subject", ""),
                "priority": topic.get("priority", "MED"),
                "difficulty": topic.get("difficulty", 3),
                "allocated_minutes": day["allocated_minutes"],
                "revision_topic_ids": day.get("revision_topic_ids") or [],
                "status": day["status"],
                "taught_at": day.get("taught_at"),
            }
        )
    return {
        "plan_id": plan["id"],
        "id": plan["id"],
        "user_id": plan["user_id"],
        "exam_id": plan["exam_id"],
        "exam": exam_name,
        "level": plan.get("level", "beginner"),
        "start_date": plan["start_date"],
        "end_date": plan["end_date"],
        "duration": plan["duration_days"],
        "duration_days": plan["duration_days"],
        "status": plan["status"],
        "created_at": plan.get("created_at"),
        "days": payload_days,
        "meta": plan.get("meta") or {},
    }


def build_study_plan(
    user_id: str,
    exam_id_or_name: str,
    duration_days: int,
    start_date: str | None = None,
    name: str = "Learner",
    level: str = "beginner",
) -> dict[str, Any]:
    _seed_static_data()
    duration_days = max(2, min(7, int(duration_days)))
    exam_id = _exam_id(exam_id_or_name)
    start = date.fromisoformat(start_date) if start_date else date.today()
    end = start + timedelta(days=duration_days - 1)
    _ensure_user(user_id, name=name, level=level, exam_id=exam_id)

    weak_rows = _data(_table("user_performance").select("*").eq("user_id", user_id).execute())
    weak_scores = {row["topic_id"]: float(row.get("weakness_score") or 0) for row in weak_rows}
    priority_score = {"HIGH": 0, "MED": 1, "LOW": 2}
    topics = sorted(
        list_topics(exam_id),
        key=lambda topic: (
            -weak_scores.get(topic["id"], 0),
            priority_score.get(topic["priority"], 3),
            topic["difficulty"],
            topic["name"],
        ),
    )

    _table("study_plans").update({"status": "abandoned"}).eq("user_id", user_id).eq("status", "active").execute()

    plan_id = _new_id("plan")
    plan = {
        "id": plan_id,
        "user_id": user_id,
        "exam_id": exam_id,
        "level": level,
        "start_date": start.isoformat(),
        "end_date": end.isoformat(),
        "duration_days": duration_days,
        "status": "active",
        "planner_version": 1,
        "meta": {},
    }
    _table("study_plans").insert(plan).execute()

    days = []
    for index in range(duration_days):
        topic = topics[index % len(topics)]
        weak = weak_scores.get(topic["id"], 0) >= 60
        days.append(
            {
                "id": _new_id("day"),
                "plan_id": plan_id,
                "day_number": index + 1,
                "scheduled_date": (start + timedelta(days=index)).isoformat(),
                "topic_id": topic["id"],
                "revision_topic_ids": [days[index - 2]["topic_id"]] if index >= 2 else [],
                "allocated_minutes": 110 if weak else 90,
                "status": "pending",
            }
        )
    _table("study_plan_days").insert(days).execute()
    return _plan_payload(plan)


def get_active_plan(user_id: str) -> dict[str, Any] | None:
    _seed_static_data()
    plan = _one(
        _table("study_plans")
        .select("*")
        .eq("user_id", user_id)
        .eq("status", "active")
        .order("created_at", desc=True)
        .limit(1)
        .execute()
    )
    return _plan_payload(plan) if plan else None


def get_plan_by_day(plan_day_id: str) -> tuple[dict[str, Any], dict[str, Any]] | None:
    day = _one(_table("study_plan_days").select("*").eq("id", plan_day_id).limit(1).execute())
    if not day:
        return None
    plan = _one(_table("study_plans").select("*").eq("id", day["plan_id"]).limit(1).execute())
    if not plan:
        return None
    full_plan = _plan_payload(plan)
    full_day = next((item for item in full_plan["days"] if item["id"] == plan_day_id), None)
    return (full_plan, full_day) if full_day else None


def lesson_for_topic(topic_name: str, level: str = "beginner") -> str:
    points = LESSON_POINTS.get(topic_name, LESSON_POINTS["Percentage"])
    depth = {
        "beginner": "simple language and one careful example",
        "intermediate": "standard exam shortcuts and practice framing",
        "advanced": "fast recall, traps, and shortcut checks",
    }.get(level, "simple language and one careful example")
    example = {
        "Percentage": "If 30% of a value is 90, the full value is 90 x 100 / 30 = 300.",
        "Profit & Loss": "If CP is 800 and SP is 920, profit is 120 and profit percent is 120/800 x 100 = 15%.",
        "Time & Work": "If A takes 10 days and B takes 15 days, together they finish 1/10 + 1/15 = 1/6 work per day.",
    }.get(topic_name, "Write the data in a table, apply the rule step by step, and verify with the options.")
    return (
        f"### What is {topic_name}?\n"
        f"{topic_name} is an exam topic that rewards clear setup, reliable formulas, and fast checking. "
        f"For a {level} learner, focus on {depth}.\n\n"
        "### Key Concepts\n"
        + "\n".join(f"- {point}" for point in points)
        + "\n\n### Worked Example\n"
        + example
        + "\n\n### Common Mistakes\n"
        "- Calculating on the wrong base value.\n"
        "- Skipping units, direction, or conditions given in the question.\n"
        "- Choosing an option before checking the final result.\n\n"
        "### Quick Formula/Trick\n"
        "Convert the question into a small equation or table first; the calculation becomes much safer."
    )


def teach_plan_day(plan_day_id: str, user_id: str) -> dict[str, Any]:
    found = get_plan_by_day(plan_day_id)
    if not found:
        raise ValueError("Plan day not found")
    plan, day = found
    _ensure_user(user_id, level=plan.get("level", "beginner"), exam_id=plan.get("exam_id", "exam-ssc-cgl"))
    content = lesson_for_topic(day["topic_name"], plan.get("level", "beginner"))
    taught_at = datetime.now().isoformat(timespec="seconds")
    _table("study_plan_days").update({"status": "taught", "taught_at": taught_at}).eq("id", plan_day_id).execute()
    log_id = _new_id("log")
    _table("teaching_logs").insert(
        {
            "id": log_id,
            "plan_day_id": plan_day_id,
            "user_id": user_id,
            "topic_id": day["topic_id"],
            "content_summary": content,
            "revision_covered": day.get("revision_topic_ids") or [],
            "llm_trace": {},
            "duration_mins": day.get("allocated_minutes", 90),
        }
    ).execute()
    return {"log_id": log_id, "lesson_content": content, "topic_name": day["topic_name"], "status": "taught"}


def _questions_for_topic(topic_name: str, num_questions: int) -> list[dict[str, Any]]:
    bank = QUIZ_BANK.get(topic_name, QUIZ_BANK["default"])
    selected = random.sample(bank, min(num_questions, len(bank)))
    while len(selected) < num_questions:
        selected.append(random.choice(bank))
    return [
        {"question_text": q, "options": options, "correct_index": answer, "explanation": explanation}
        for q, options, answer, explanation in selected
    ]


def generate_quiz(user_id: str, topic_id: str, num_questions: int = 5, difficulty: int = 3, plan_day_id: str | None = None) -> dict[str, Any]:
    topic = _one(_table("syllabus_topics").select("*").eq("id", topic_id).limit(1).execute())
    if not topic and plan_day_id:
        found = get_plan_by_day(plan_day_id)
        if found:
            topic = {"id": found[1]["topic_id"], "topic_name": found[1]["topic_name"]}
    if not topic:
        topic = {"id": topic_id, "topic_name": "Percentage"}
    questions = _questions_for_topic(topic["topic_name"], max(3, min(20, int(num_questions))))
    attempt_id = _new_id("attempt")
    _table("quiz_attempts").insert(
        {
            "id": attempt_id,
            "user_id": user_id,
            "topic_id": topic["id"],
            "plan_day_id": plan_day_id,
            "questions": questions,
            "total_questions": len(questions),
            "difficulty": difficulty,
        }
    ).execute()
    return {
        "attempt_id": attempt_id,
        "questions": [{"question_text": q["question_text"], "options": q["options"]} for q in questions],
        "total": len(questions),
    }


def _top_weaknesses(user_id: str) -> list[dict[str, Any]]:
    rows = _data(
        _table("user_performance")
        .select("*")
        .eq("user_id", user_id)
        .order("weakness_score", desc=True)
        .limit(10)
        .execute()
    )
    topics = _topic_map([row["topic_id"] for row in rows])
    return [
        {
            "topic_id": row["topic_id"],
            "topic_name": topics.get(row["topic_id"], {}).get("topic_name", row["topic_id"]),
            "weakness_score": float(row.get("weakness_score") or 50.0),
            "rank": index + 1,
            "recommended_extra_mins": 20 if float(row.get("weakness_score") or 0) >= 60 else 0,
        }
        for index, row in enumerate(rows)
    ]


def submit_quiz(attempt_id: str, user_answers: list[int], time_taken_secs: int) -> dict[str, Any]:
    attempt = _one(_table("quiz_attempts").select("*").eq("id", attempt_id).limit(1).execute())
    if not attempt:
        raise ValueError("Attempt not found")
    questions = attempt["questions"]
    results = [
        int(user_answers[index]) == int(question["correct_index"])
        for index, question in enumerate(questions)
    ]
    total = len(questions)
    score = sum(results)
    accuracy = round(score * 100 / total, 2) if total else 0.0
    submitted_at = datetime.now().isoformat(timespec="seconds")
    _table("quiz_attempts").update(
        {
            "user_answers": user_answers,
            "score": score,
            "accuracy": accuracy,
            "time_taken_secs": time_taken_secs,
            "submitted_at": submitted_at,
        }
    ).eq("id", attempt_id).execute()

    user_id = attempt["user_id"]
    topic_id = attempt["topic_id"]
    current = _one(
        _table("user_performance")
        .select("*")
        .eq("user_id", user_id)
        .eq("topic_id", topic_id)
        .limit(1)
        .execute()
    )
    attempts = int((current or {}).get("attempts") or 0) + total
    correct = int((current or {}).get("correct") or 0) + score
    updated_accuracy = round(correct * 100 / attempts, 2) if attempts else 0.0
    new_weakness_score = round((1 - updated_accuracy / 100) * 70 + 9, 2)
    perf = {
        "id": (current or {}).get("id") or _new_id("perf"),
        "user_id": user_id,
        "topic_id": topic_id,
        "attempts": attempts,
        "correct": correct,
        "accuracy": updated_accuracy,
        "avg_time_secs": round(time_taken_secs / total, 2) if total else 0,
        "weakness_score": new_weakness_score,
        "last_attempted": submitted_at,
    }
    _table("user_performance").upsert(perf, on_conflict="user_id,topic_id").execute()

    recent = _data(
        _table("quiz_attempts")
        .select("accuracy")
        .eq("user_id", user_id)
        .eq("topic_id", topic_id)
        .order("submitted_at", desc=True)
        .limit(2)
        .execute()
    )
    replan_triggered = len(recent) >= 2 and all(float(row.get("accuracy") or 0) < 40 for row in recent) and updated_accuracy < 40
    if replan_triggered:
        plan = _one(_table("study_plans").select("*").eq("user_id", user_id).eq("status", "active").limit(1).execute())
        if plan:
            meta = plan.get("meta") or {}
            topic = _one(_table("syllabus_topics").select("topic_name").eq("id", topic_id).limit(1).execute()) or {}
            meta.update(
                {
                    "replan_flag": True,
                    "replan_reason": f"accuracy < 40% for 2 sessions on {topic.get('topic_name', topic_id)}",
                    "affected_topics": [topic_id],
                    "flagged_at": submitted_at,
                }
            )
            _table("study_plans").update({"meta": meta}).eq("id", plan["id"]).execute()

    return {
        "score": score,
        "total": total,
        "accuracy": accuracy,
        "per_question_result": results,
        "updated_accuracy": updated_accuracy,
        "new_weakness_score": new_weakness_score,
        "replan_triggered": replan_triggered,
        "top_weak_topics": _top_weaknesses(user_id),
    }


def get_progress(user_id: str) -> dict[str, Any]:
    rows = _data(
        _table("user_performance")
        .select("*")
        .eq("user_id", user_id)
        .order("weakness_score", desc=True)
        .execute()
    )
    topics = _topic_map([row["topic_id"] for row in rows])
    topic_stats = [
        {
            "topic_id": row["topic_id"],
            "topic_name": topics.get(row["topic_id"], {}).get("topic_name", row["topic_id"]),
            "attempts": int(row.get("attempts") or 0),
            "correct": int(row.get("correct") or 0),
            "accuracy": float(row.get("accuracy") or 0.0),
            "weakness_score": float(row.get("weakness_score") or 50.0),
        }
        for row in rows
    ]
    return {"topic_stats": topic_stats, "top_weaknesses": _top_weaknesses(user_id)}


def replan_user(user_id: str) -> dict[str, Any]:
    active = get_active_plan(user_id)
    if not active:
        raise ValueError("No active plan to replan")
    weak_rows = _data(_table("user_performance").select("*").eq("user_id", user_id).execute())
    weak_scores = {row["topic_id"]: float(row.get("weakness_score") or 0) for row in weak_rows}
    pending = [day for day in active["days"] if day["status"] == "pending"]
    pending.sort(key=lambda day: weak_scores.get(day["topic_id"], 0), reverse=True)
    pending_iter = iter(pending)
    updates = []
    for index, day in enumerate(active["days"]):
        if day["status"] != "pending":
            continue
        replacement = next(pending_iter)
        score = weak_scores.get(replacement["topic_id"], 0)
        updates.append(
            {
                "id": day["id"],
                "topic_id": replacement["topic_id"],
                "allocated_minutes": 110 if score >= 60 else 90,
                "revision_topic_ids": [active["days"][index - 2]["topic_id"]] if index >= 2 else [],
            }
        )
    for update in updates:
        row_id = update.pop("id")
        _table("study_plan_days").update(update).eq("id", row_id).execute()
    meta = active.get("meta") or {}
    meta["replanned_at"] = datetime.now().isoformat(timespec="seconds")
    meta.pop("replan_flag", None)
    _table("study_plans").update({"meta": meta}).eq("id", active["id"]).execute()
    return {"updated_plan_id": active["plan_id"], "message": f"Plan created: plan_id={active['plan_id']}, remaining days adjusted for weak areas"}

